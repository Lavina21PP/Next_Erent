"use client";
import { useEffect, useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import {
  emailValidate,
  NumberValidate,
  PhoneNumberValidate,
} from "@/components/validate/validate";

export default function Example() {
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });
useEffect(() => {
  setError(prev => ({
    ...prev,
    username: error.username ? "" : prev.username,
    password: error.password ? "" : prev.password,
  }));
}, [formData.username, formData.password]);

  const validatedEmail = emailValidate.safeParse(formData.username);
  const validatedPhoneNumber = PhoneNumberValidate.safeParse(formData.username);
  const validatedNumber = NumberValidate.safeParse(formData.username);

  const [showPassword, setShowPassword] = useState(false);
  interface TypeError {
    username: any;
    password: string;
  }
  const [error, setError] = useState<TypeError>({
    username: "",
    password: "",
  });
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validatedNumber.success) {
      if (validatedPhoneNumber.success) {
        setError((prev) => ({
          ...prev,
          username: "Phone Number True",
        }));
      } else {
        setError((prev) => ({
          ...prev,
          username: validatedPhoneNumber.error?.issues[0].message,
        }));
      }
    } else {
      if (validatedEmail.success) {
        setError((prev) => ({
          ...prev,
          username: "Email True",
        }));
      } else {
        setError((prev) => ({
          ...prev,
          username: "Not Found Email",
        }));
      }
    }
  };

  return (
    <>
      <div className="flex min-h-full flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">
          <img
            alt="Your Company"
            src="t2logo.png"
            className="mx-auto h-10 w-auto"
          />
          <h2 className="mt-10 text-center text-2xl/9 font-bold tracking-tight">
            Sign in to your account
          </h2>
        </div>

        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email */}
            <div>
              <label htmlFor="username" className="block text-sm/6 font-medium">
                Email | Phone Number
              </label>
              <div className="mt-2">
                <input
                  id="username"
                  name="username"
                  type="text"
                  placeholder="Input Your Email or PhoneNumber"
                  value={formData.username}
                  onChange={handleChange}
                  required
                  autoComplete="username"
                  className="border border-[#a5a5a5] block w-full rounded-md bg-white/5 px-3 py-1.5 text-base outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                />
              </div>
              <div className="k text-red-600">{error.username}</div>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between">
                <label
                  htmlFor="password"
                  className="block text-sm/6 font-medium"
                >
                  Password
                </label>
                <div className="text-sm">
                  <a
                    href="#"
                    className="font-semibold text-indigo-400 hover:text-indigo-300"
                  >
                    Forgot password?
                  </a>
                </div>
              </div>
              <div className="mt-2 relative">
                <input
                  id="password"
                  name="password"
                  placeholder="Input Your Password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleChange}
                  required
                  autoComplete="current-password"
                  className="border border-[#a5a5a5] block w-full rounded-md bg-white/5 px-3 py-1.5 pr-10 text-base outline-1 -outline-offset-1 outline-white/10 placeholder:text-gray-500 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-500 sm:text-sm/6"
                />
                <button
                  type="button"
                  onClick={togglePasswordVisibility}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-200"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              <div className="k text-red-600">{error.password}</div>
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-indigo-500 px-3 py-1.5 text-sm/6 font-semibold text-white hover:bg-indigo-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500"
              >
                Sign In
              </button>
            </div>
          </form>

          {/* Footer */}
          <p className="mt-10 text-center text-sm/6 text-gray-400">
            Don't have an account?{" "}
            <a
              href="/register"
              className="font-semibold text-blue-600 hover:text-indigo-300"
            >
              Sign Up
            </a>
          </p>
        </div>
      </div>
    </>
  );
}
