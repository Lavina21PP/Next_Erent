"use client";
import { useState, useRef, useEffect } from "react";
import {
  Eye,
  EyeOff,
  Mail,
  Phone,
  User,
  Lock,
  Shield,
  CheckCircle,
  X,
} from "lucide-react";
import Confirmotp from "../confirmotp/confirmotp";

// Mock validation functions (replace with your actual validation)
const emailValidate = {
  safeParse: (email: string) => ({
    success: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
  }),
};

const PhoneNumberValidate = {
  safeParse: (phone: string) => ({
    success: /^[+]?[\d\s-()]{10,}$/.test(phone),
  }),
};

interface FormErrors {
  fname?: string;
  lname?: string;
  username?: string;
  password?: string;
  confirmPassword?: string;
  role?: string;
}

export default function App() {
  const [formData, setFormData] = useState({
    fname: "",
    lname: "",
    username: "",
    password: "",
    confirmPassword: "",
    role: "", // เปลี่ยนค่าเริ่มต้นเป็นค่าว่าง
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showOTP, setShowOTP] = useState(false);
  const [otpTimer, setOtpTimer] = useState(60);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});

  // Use useRef to store the timer ID
  const otpTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Clear error when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const validateForm = (): FormErrors => {
    const newErrors: FormErrors = {};

    // Name validation
    if (!formData.fname.trim()) {
      newErrors.fname = "First name is required";
    } else if (formData.fname.trim().length < 2) {
      newErrors.fname = "First name must be at least 2 characters";
    }

    if (!formData.lname.trim()) {
      newErrors.lname = "Last name is required";
    } else if (formData.lname.trim().length < 2) {
      newErrors.lname = "Last name must be at least 2 characters";
    }

    // Username validation (email or phone)
    if (!formData.username.trim()) {
      newErrors.username = "Email or phone number is required";
    } else {
      const validatedEmail = emailValidate.safeParse(formData.username);
      const validatedPhone = PhoneNumberValidate.safeParse(formData.username);

      if (!validatedEmail.success && !validatedPhone.success) {
        newErrors.username = "Please enter a valid email or phone number";
      }
    }

    // Password validation
    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(formData.password)) {
      newErrors.password =
        "Password must contain uppercase, lowercase, and number";
    }

    // Confirm password validation
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = "Please confirm your password";
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }

    // Role validation
    if (!formData.role) {
      // ตรวจสอบว่าไม่ได้เลือก Account Type
      newErrors.role = "Account type is required";
    }

    return newErrors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors = validateForm();
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setIsLoading(true);
      // Simulate API call for signup
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setIsLoading(false);
      setShowOTP(true);
      startOtpTimer();
    }
  };

  const startOtpTimer = () => {
    setOtpTimer(60);
    // Clear any existing timer before starting a new one
    if (otpTimerRef.current) {
      clearInterval(otpTimerRef.current);
    }

    const timer = setInterval(() => {
      setOtpTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          otpTimerRef.current = null; // Clear the ref
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    otpTimerRef.current = timer; // Store the timer ID in ref
  };
  const resendOTP = () => {
    if (otpTimer === 0) {
      // Simulate API call to resend OTP
      console.log("OTP resent");
      startOtpTimer();
    }
  };

  // Cleanup effect: clear timer if component unmounts
  useEffect(() => {
    return () => {
      if (otpTimerRef.current) {
        clearInterval(otpTimerRef.current);
        otpTimerRef.current = null;
      }
    };
  }, []);

  const getInputIcon = (field: string) => {
    switch (field) {
      case "fname":
      case "lname":
        return <User size={18} className="text-gray-400" />;
      case "username":
        return formData.username.includes("@") ? (
          <Mail size={18} className="text-gray-400" />
        ) : (
          <Phone size={18} className="text-gray-400" />
        );
      case "password":
      case "confirmPassword":
        return <Lock size={18} className="text-gray-400" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center shadow-lg">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Create Account
          </h1>
          <p className="text-gray-600">Join us today and get started</p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name Fields */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="fname"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  First Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    {getInputIcon("fname")}
                  </div>
                  <input
                    id="fname"
                    name="fname"
                    type="text"
                    value={formData.fname}
                    onChange={handleChange}
                    placeholder="John"
                    className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 ${
                      errors.fname
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-indigo-500"
                    }`}
                  />
                </div>
                {errors.fname && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <X size={14} className="mr-1 inline-block" />
                    {errors.fname}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="lname"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Last Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    {getInputIcon("lname")}
                  </div>
                  <input
                    id="lname"
                    name="lname"
                    type="text"
                    value={formData.lname}
                    onChange={handleChange}
                    placeholder="Doe"
                    className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 ${
                      errors.lname
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-indigo-500"
                    }`}
                  />
                </div>
                {errors.lname && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <X size={14} className="mr-1 inline-block" />
                    {errors.lname}
                  </p>
                )}
              </div>
            </div>

            {/* Username */}
            <div>
              <label
                htmlFor="username"
                className="block text-sm font-semibold text-gray-700 mb-2"
              >
                Email or Phone Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  {getInputIcon("username")}
                </div>
                <input
                  id="username"
                  name="username"
                  type="text"
                  value={formData.username}
                  onChange={handleChange}
                  placeholder="john@example.com or +1234567890"
                  className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 ${
                    errors.username
                      ? "border-red-400 bg-red-50"
                      : "border-gray-200 focus:border-indigo-500"
                  }`}
                />
              </div>
              {errors.username && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <X size={14} className="mr-1 inline-block" />
                  {errors.username}
                </p>
              )}
            </div>

            {/* Role */}
            <div className="relative">
              {" "}
              {/* Added relative for dropdown arrow positioning */}
              <label
                htmlFor="role"
                className="block text-sm font-semibold text-gray-700 mb-2"
              >
                Account Type
              </label>
              <select
                id="role"
                name="role"
                value={formData.role}
                onChange={handleChange}
                className={`w-full px-4 py-3 border-2 rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 appearance-none bg-white pr-8 ${
                  errors.role
                    ? "border-red-400 bg-red-50"
                    : "border-gray-200 focus:border-indigo-500"
                }`}
              >
                <option value="" disabled>
                  Select Account Type
                </option>{" "}
                {/* เพิ่ม option ที่เป็นค่าว่างและ disabled */}
                <option value="TENANT">Tenant</option>
                <option value="LANDLORD">Landlord</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                <svg
                  className="fill-current h-4 w-4"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 6.757 7.586 5.343 9l4.95 4.95z" />
                </svg>
              </div>
              {errors.role && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <X size={14} className="mr-1 inline-block" />
                  {errors.role}
                </p>
              )}
            </div>

            {/* Password Fields */}
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label
                  htmlFor="password"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    {getInputIcon("password")}
                  </div>
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Create a strong password"
                    className={`w-full pl-10 pr-12 py-3 border-2 rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 ${
                      errors.password
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-indigo-500"
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                {errors.password && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <X size={14} className="mr-1 inline-block" />
                    {errors.password}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="confirmPassword"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Confirm Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    {getInputIcon("confirmPassword")}
                  </div>
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    placeholder="Confirm your password"
                    className={`w-full pl-10 pr-12 py-3 border-2 rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 ${
                      errors.confirmPassword
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-indigo-500"
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    {showConfirmPassword ? (
                      <EyeOff size={18} />
                    ) : (
                      <Eye size={18} />
                    )}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <X size={14} className="mr-1 inline-block" />
                    {errors.confirmPassword}
                  </p>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Creating Account...
                </>
              ) : (
                "Create Account"
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Already have an account?{" "}
              <a
                href="/login"
                className="text-indigo-600 hover:text-indigo-700 font-semibold transition-colors"
              >
                Sign in here
              </a>
            </p>
          </div>
        </div>
      </div>

      {/* OTP Modal */}
      {showOTP && (
        <Confirmotp
          formData={formData}
          setFormData={setFormData}
          setShowOTP={setShowOTP}
          otpTimer={otpTimer}
          resendOTP={resendOTP}
        />
      )}
    </div>
  );
}
