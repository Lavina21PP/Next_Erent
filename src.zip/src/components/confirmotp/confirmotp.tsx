"use client";
import { CheckCircle, Shield } from "lucide-react";
import React, { useRef, useState } from "react";

function Confirmotp({
  formData,
  setFormData,
  setShowOTP,
  otpTimer,
  resendOTP,
}: {
  formData: any;
  setFormData: any;
  setShowOTP: any;
  otpTimer: any;
  resendOTP: any;
}) {
  const [otp, setOTP] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const otpTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleOTPSubmit = async () => {
    if (otp.length !== 6) return;
    setIsLoading(true);
    // Simulate OTP verification
    await new Promise((resolve) => setTimeout(resolve, 1000));
    console.log("Account created successfully:", formData);
    setIsLoading(false);

    // Clear timer on successful submit
    if (otpTimerRef.current) {
      clearInterval(otpTimerRef.current);
      otpTimerRef.current = null;
    }
    setShowOTP(false);
    //send success

    setOTP("");
  };


  const handleCloseOTPModal = () => {
    if (otpTimerRef.current) {
      clearInterval(otpTimerRef.current);
      otpTimerRef.current = null;
    }
    setShowOTP(false);
  };
  return (
    <div>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 transform scale-100 transition-all duration-300">
          <div className="text-center mb-6">
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">
              Verify Your Account
            </h3>
            <p className="text-gray-600">
              Enter the 6-digit code sent to your{" "}
              {formData.username.includes("@") ? "email" : "phone"}
            </p>
          </div>

          <div className="mb-6">
            <input
              type="text"
              value={otp}
              onChange={(e) =>
                setOTP(e.target.value.replace(/\D/g, "").slice(0, 6))
              }
              placeholder="••••••"
              maxLength={6}
              className="w-full text-center text-2xl font-mono tracking-[0.5em] py-4 px-4 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all duration-200"
            />
          </div>

          <div className="flex justify-between items-center mb-6 text-sm">
            <button
              onClick={resendOTP}
              disabled={otpTimer > 0}
              className={`font-medium transition-colors ${
                otpTimer > 0
                  ? "text-gray-400 cursor-not-allowed"
                  : "text-indigo-600 hover:text-indigo-700"
              }`}
            >
              {otpTimer > 0 ? `Resend in ${otpTimer}s` : "Resend Code"}
            </button>
            {otpTimer > 0 && (
              <span className="text-gray-500">
                {`(${otpTimer}s remaining)`}
              </span>
            )}
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleCloseOTPModal}
              className="flex-1 py-3 px-4 border-2 border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors duration-200 font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleOTPSubmit}
              disabled={otp.length !== 6 || isLoading}
              className="flex-1 py-3 px-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none font-medium flex items-center justify-center"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Verifying...
                </>
              ) : (
                <>
                  <CheckCircle className="inline w-4 h-4 mr-2" />
                  Verify
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Confirmotp;
