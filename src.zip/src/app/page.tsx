import React from 'react'

function Page() {
  return (
    <div>Page</div>
  )
}

export default Page