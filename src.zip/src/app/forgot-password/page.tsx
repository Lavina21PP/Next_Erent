"use client";
import { useRef, useState } from "react";
import { PhoneNumberValidate, emailValidate } from "@/components/validate/validate";
import Confirmotp from "@/components/confirmotp/confirmotp";

export default function ForgotPassword() {
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");
  const [showOTP, setShowOTP] = useState(false);
  const [otpTimer, setOtpTimer] = useState(60);
  const otpTimerRef = useRef<NodeJS.Timeout | null>(null);

  const startOtpTimer = () => {
    setOtpTimer(60);
    if (otpTimerRef.current) clearInterval(otpTimerRef.current);
    otpTimerRef.current = setInterval(() => {
      setOtpTimer((prev) => (prev <= 1 ? (clearInterval(otpTimerRef.current!), 0) : prev - 1));
    }, 1000);
  };

  const resendOTP = () => {
    if (otpTimer === 0) {
      console.log("OTP resent");
      startOtpTimer();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !emailValidate.safeParse(username).success &&
      !PhoneNumberValidate.safeParse(username).success
    ) {
      setError("Invalid Email or Phone Number");
      return;
    }
    setError("");
    setShowOTP(true);
    startOtpTimer();
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6 py-12">
      <form onSubmit={handleSubmit} className="space-y-4 w-full max-w-sm">
        <h2 className="text-2xl font-bold text-center">Forgot Password</h2>
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Enter Email or Phone Number"
          className="border w-full rounded-md px-3 py-2"
        />
        {error && <div className="text-red-600">{error}</div>}
        <button className="w-full bg-indigo-500 text-white px-3 py-2 rounded-md hover:bg-indigo-400">
          Submit
        </button>
      </form>

      {showOTP && (
        <Confirmotp
          formData={{ username }}
          setFormData={{ setUsername }}
          setShowOTP={setShowOTP}
          otpTimer={otpTimer}
          resendOTP={resendOTP}
        />
      )}
    </div>
  );
}
