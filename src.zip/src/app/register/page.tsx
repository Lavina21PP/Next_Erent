import Signup from '@/components/auth/register'
import React from 'react'

function Page() {
  return (
    <div>
        <Signup />
    </div>
  )
}

export default Page