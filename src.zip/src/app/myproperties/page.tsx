import MyProperties from '@/components/landlord/myproperties/Myproperties'
import React from 'react'

function Page() {
  return (
    <div>
        <MyProperties />
    </div>
  )
}

export default Page