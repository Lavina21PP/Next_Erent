import Example from '@/components/auth/login'
import React from 'react'

function Page() {
  return (
    <div>
        <Example />
    </div>
  )
}

export default Page